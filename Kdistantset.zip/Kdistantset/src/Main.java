import java.util.LinkedList;

import Itemset.DataSet;
import Itemset.DatasetWriter;
import Itemset.Itemset;
import Itemset.Reader;
import PreSolver.PreSolver;
import Solver.FinalSolver;
import ilog.concert.IloException;

public class Main {
	// folder, ItemsetFile, sizemin, sizemax, k-anoimity, columnsNumber, editdistance, algorithm 1/2
	
	public static void main(String[] args) {
		String folder=args[0];
		//String datasetName=args[1];
		String itemsetFile=args[1];
		int sl=Integer.parseInt(args[2]);
		int su=Integer.parseInt(args[3]);
		int k=Integer.parseInt(args[4]);
		int cn=Integer.parseInt(args[5]);
		int ed=Integer.parseInt(args[6]);
		int alg=Integer.parseInt(args[7]);
		Reader r=new Reader();
		LinkedList<Itemset> its=r.readItemset(folder+"/"+itemsetFile);
		//System.out.println(its);
		DataSet d=null;
		try {
			d = PreSolver.solver(its, sl, su, k);
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(d.getDataset().keySet());
		long h=System.currentTimeMillis();
		FinalSolver fs=new FinalSolver();
		LinkedList<DataSet> ld =null;
		if(alg==1){
			ld=fs.solve1(d, its, sl, su, k, ed,cn);
		}else{
			ld=fs.solve2(d, its, sl, su, k, ed,cn);
		}
		h=System.currentTimeMillis()-h;
		System.out.println("execTime(mces)="+h);
		System.out.println("distance="+fs.getOptm());
		int i=0;
		for(DataSet d1:ld){
			if(d!=d1){
				DatasetWriter dw=new DatasetWriter(folder+"/"+sl+"-"+su+"-"+k+"-"+cn+"-"+ed+"-"+alg+"-"+i+"-"+itemsetFile);
				dw.writeDataset(d1);
				i++;
			}
		}
	}

}
