package Solver;

import java.util.LinkedList;

import Itemset.DataSet;
import Itemset.Itemset;
import ilog.concert.IloException;

public class FinalSolver {
	
	double optm=0;
	
	public LinkedList<DataSet> solve1(DataSet dataset,LinkedList<Itemset> list,int sl,int su,int k,int editdistance, int cn){
		LinkedList<DataSet> set=new LinkedList<>();
		set.add(dataset);
		for(int i=0;i<k;i++){
			try {
				IntermediateSolver is=new IntermediateSolver(set, list, sl, su, editdistance);
				DataSet ds=is.solve(cn);
				optm+=-is.sc.solver.getBestObjValue();
				set.add(ds);
			} catch (IloException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
		}
		return set;
		
	}
	
	public LinkedList<DataSet> solve2(DataSet dataset,LinkedList<Itemset> list,int sl,int su,int k,int editdistance, int cn){
		LinkedList<DataSet> set=new LinkedList<>();
		set.add(dataset);
		for(int i=0;i<k;i++){
			try {
				IntermediateSolver is=new IntermediateSolver(set, list, sl, su, editdistance);
				DataSet ds=is.solve2(cn);
				optm+=-is.sc.solver.getBestObjValue();
				set.add(ds);
			} catch (IloException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
		}
		return set;
		
	}

	public double getOptm() {
		return optm;
	}

	public void setOptm(double optm) {
		this.optm = optm;
	}

}
