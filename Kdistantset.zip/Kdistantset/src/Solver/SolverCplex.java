package Solver;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import Itemset.DataSet;
import Itemset.Itemset;
import Itemset.TransDupl;
import Itemset.Transaction;
import ilog.concert.IloColumnArray;
import ilog.concert.IloConversion;
import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloNumVarType;
import ilog.concert.IloObjective;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import ilog.cplex.IloCplex.UnknownObjectException;


public class SolverCplex {
	
	public LinkedList<DataSet> getDatasets() {
		return datasets;
	}

	public void setDatasets(LinkedList<DataSet> datasets) {
		this.datasets = datasets;
	}

	public LinkedList<Itemset> getList() {
		return list;
	}

	public void setList(LinkedList<Itemset> list) {
		this.list = list;
	}

	public HashSet<Transaction> getAllTransactions() {
		return allTransactions;
	}

	public void setAllTransactions(HashSet<Transaction> allTransactions) {
		this.allTransactions = allTransactions;
	}

	public IloCplex getSolver() {
		return solver;
	}

	public void setSolver(IloCplex solver) {
		this.solver = solver;
	}

	public IloRange getSizemin() {
		return sizemin;
	}

	public void setSizemin(IloRange sizemin) {
		this.sizemin = sizemin;
	}

	public IloRange getSizemax() {
		return sizemax;
	}

	public void setSizemax(IloRange sizemax) {
		this.sizemax = sizemax;
	}

	public int getSl() {
		return sl;
	}

	public void setSl(int sl) {
		this.sl = sl;
	}

	public int getSu() {
		return su;
	}

	public void setSu(int su) {
		this.su = su;
	}


	public IloObjective getMaxfun() {
		return maxfun;
	}

	public void setMaxfun(IloObjective maxfun) {
		this.maxfun = maxfun;
	}

	LinkedList<DataSet> datasets= new LinkedList<>();
	LinkedList<Itemset> list=new LinkedList<>();
	HashSet<Transaction> allTransactions;
	LinkedList<Transaction> previousTrans;
	IloCplex solver;
	IloRange sizemin;
	IloRange sizemax;
	int sl;
	int su;
	IloObjective maxfun;
	HashMap<Transaction,Double> kt=new HashMap<>();
	
	public SolverCplex(LinkedList<DataSet> datasets,LinkedList<Itemset> list,int sl,int su) throws IloException{
		solver=new IloCplex();
		solver.setOut(new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
		});
		solver.setWarning(new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
		});
		//solver.setOut(null);
		this.datasets=datasets;
		this.list=list;
		this.sl=sl;
		this.su=su;
	}
	
	public boolean check() throws UnknownObjectException, IloException{
		double sum=0;
		for(Transaction t:previousTrans){
			sum+=solver.getValue(t.getX());
		}
		return sum<su;
	}
	
	
	public void Initialization() throws IloException{
		previousTrans=new LinkedList<>();
		allTransactions=new HashSet<>();
		for(DataSet d:datasets){
			allTransactions.addAll(d.getDataset().keySet());
		}
		for(Transaction t:allTransactions){
			double k=su;
			for(Itemset is: list){
				if(t.getS().containsAll(is.getS()))
					if(k>is.getSmax()){
						k= is.getSmax();
					}
			}
			kt.put(t, k);
			t.setX(solver.numVar(0, Double.MAX_VALUE));
		}
		for(DataSet d: datasets){
			for(Transaction t:d.getDataset().keySet()){
				TransDupl td=d.getDataset().get(t);
				if(td.getV()>0){
					td.setY(solver.numVar(0, Double.MAX_VALUE));
					//td.setYmin(solver.numVar(0, td.getV()));
					//td.setYmax(solver.numVar(td.getV(), Double.MAX_VALUE));
					//td.setz(solver.numVar(1, 1));
					td.setz(solver.numVar(0, 1));
				}
			}
		}
	    IloNumExpr sum=null;
	    HashSet<Transaction> lt=new HashSet<>();
		for(DataSet d:datasets){
			for(Transaction t: d.getDataset().keySet()){
				TransDupl td=d.getDataset().get(t);
				if(td.getV()>0){
					if(sum==null){
						sum=solver.prod(-1,td.getY());
					}else{
						sum=solver.sum(sum,solver.prod(-1,td.getY()));
					}
				}else{
					lt.add(t);
				}
			}
		}
		HashSet<Transaction> set=new HashSet<>(allTransactions);
		set.retainAll(lt);
		for(Transaction t:lt){
			sum=solver.sum(sum,solver.prod(-datasets.size(),t.getX()));
		}
		maxfun=solver.addMinimize(sum);
		IloNumExpr sum1=null;
		for(Itemset is: list){
			sum=null;
			sum1=null;
			for(Transaction t:allTransactions){
				if(t.getS().containsAll(is.getS())){
					if(sum==null){
						sum=t.getX();
						sum1=solver.prod(-1, t.getX());
					}else{
						sum=solver.sum(sum,t.getX());
						sum1=solver.sum(sum1,solver.prod(-1, t.getX()));
					}
				}
			}
			is.setMinc(solver.addLe(sum1, -is.getSmin()));
			is.setMaxc(solver.addLe(sum, is.getSmax()));
		}
		sum=null;
		sum1=null;
		for(Transaction t:allTransactions){
			if(sum==null){
				sum=t.getX();
				sum1=solver.prod(-1, t.getX());
			}else{
				sum=solver.sum(sum,t.getX());
				sum1=solver.sum(sum1,solver.prod(-1, t.getX()));
			}
		}
		sizemin=solver.addLe(sum1,-sl);
		sizemax=solver.addLe(sum, su);
		for(DataSet d: datasets){
			for(Transaction t:d.getDataset().keySet()){
				TransDupl td=d.getDataset().get(t);
				if(td.getV()>0){
					solver.addLe(td.getV(),solver.sum(t.getX(),td.getY()));
					solver.addLe(-td.getV(),solver.sum(solver.prod(-1, t.getX()),td.getY()));
					solver.addGe(td.getV()+2*kt.get(t),solver.sum(solver.prod(2*kt.get(t), td.getz()),solver.sum(t.getX(),td.getY())));
					solver.addGe(-td.getV(),solver.sum(solver.prod(-2*kt.get(t), td.getz()),solver.sum(solver.prod(-1,t.getX()),td.getY())));
					}
				}
			}
	}
	
	public void Initializationsec() throws IloException{
		previousTrans=new LinkedList<>();
		allTransactions=new HashSet<>();
		for(DataSet d:datasets){
			allTransactions.addAll(d.getDataset().keySet());
		}
		for(Transaction t:allTransactions){
			double k=su;
			for(Itemset is: list){
				if(t.getS().containsAll(is.getS()))
					if(k>is.getSmax()){
						k= is.getSmax();
					}
			}
			kt.put(t, k);
			t.setX(solver.numVar(0, Double.MAX_VALUE));
		}
		for(DataSet d: datasets){
			for(Transaction t:d.getDataset().keySet()){
				TransDupl td=d.getDataset().get(t);
				if(td.getV()>0){
					td.setY(solver.numVar(0, Double.MAX_VALUE));
					td.setYmin(solver.numVar(0, td.getV()));
					td.setYmax(solver.numVar(td.getV(), Double.MAX_VALUE));
					//td.setz(solver.numVar(1, 1));
					td.setz(solver.numVar(0, 1));
				}
			}
		}
	    IloNumExpr sum=null;
	    HashSet<Transaction> lt=new HashSet<>();
		for(DataSet d:datasets){
			for(Transaction t: d.getDataset().keySet()){
				TransDupl td=d.getDataset().get(t);
				if(td.getV()>0){
					if(sum==null){
						sum=solver.prod(-1,td.getY());
					}else{
						sum=solver.sum(sum,solver.prod(-1,td.getY()));
					}
				}else{
					lt.add(t);
				}
			}
		}
		HashSet<Transaction> set=new HashSet<>(allTransactions);
		set.retainAll(lt);
		for(Transaction t:lt){
			sum=solver.sum(sum,solver.prod(-datasets.size(),t.getX()));
		}
		maxfun=solver.addMinimize(sum);
		IloNumExpr sum1=null;
		for(Itemset is: list){
			sum=null;
			sum1=null;
			for(Transaction t:allTransactions){
				if(t.getS().containsAll(is.getS())){
					if(sum==null){
						sum=t.getX();
						sum1=solver.prod(-1, t.getX());
					}else{
						sum=solver.sum(sum,t.getX());
						sum1=solver.sum(sum1,solver.prod(-1, t.getX()));
					}
				}
			}
			is.setMinc(solver.addLe(sum1, -is.getSmin()));
			is.setMaxc(solver.addLe(sum, is.getSmax()));
		}
		sum=null;
		sum1=null;
		for(Transaction t:allTransactions){
			if(sum==null){
				sum=t.getX();
				sum1=solver.prod(-1, t.getX());
			}else{
				sum=solver.sum(sum,t.getX());
				sum1=solver.sum(sum1,solver.prod(-1, t.getX()));
			}
		}
		sizemin=solver.addLe(sum1,-sl);
		sizemax=solver.addLe(sum, su);
		for(DataSet d: datasets){
			for(Transaction t:d.getDataset().keySet()){
				TransDupl td=d.getDataset().get(t);
				if(td.getV()>0){
					solver.addLe(td.getV(),solver.sum(t.getX(),td.getY()));
					solver.addLe(-td.getV(),solver.sum(solver.prod(-1, t.getX()),td.getY()));
					solver.addGe(td.getV()+2*kt.get(t),solver.sum(solver.prod(2*kt.get(t), td.getz()),solver.sum(t.getX(),td.getY())));
					solver.addGe(-td.getV(),solver.sum(solver.prod(-2*kt.get(t), td.getz()),solver.sum(solver.prod(-1,t.getX()),td.getY())));
					solver.addGe(solver.sum(t.getX(),solver.prod(-1, td.getYmin())), 0);
					solver.addLe(solver.sum(t.getX(),solver.prod(-1, td.getYmax())), 0);
					solver.addLe(td.getV(),solver.sum(td.getYmin(),solver.prod(td.getV(), td.getz())));
					solver.addLe(-kt.get(t),solver.sum(td.getYmin(),solver.sum(solver.prod(-1, t.getX()),solver.prod(-kt.get(t), td.getz()))));
					solver.addGe(kt.get(t),solver.sum(td.getYmax(),solver.prod(kt.get(t)-td.getV(), td.getz())));
					solver.addGe(0,solver.sum(td.getYmax(),solver.sum(solver.prod(-1, t.getX()),solver.prod(-kt.get(t), td.getz()))));
					solver.addEq(solver.sum(solver.sum(td.getYmax(),solver.prod(-1, td.getYmin())),solver.prod(-1, td.getY())),0);
					solver.addEq(solver.sum(solver.sum(td.getYmax(),td.getYmin()),solver.prod(-1, t.getX())),td.getV());
					}
				}
			}
	}
	
	public void setBinary() throws IloException{
		int j=0;
		for(DataSet d: datasets){
			for(Transaction t:d.getDataset().keySet()){
				TransDupl td=d.getDataset().get(t);
				if(td.getV()>0){
					j+=1;
				}
			}
		}
		IloNumVar rvar[] = new IloNumVar[j];
		int i=0;
		for(DataSet d: datasets){
			for(Transaction t:d.getDataset().keySet()){
				TransDupl td=d.getDataset().get(t);
				if(td.getV()>0){
					rvar[i]=td.getz();
				    //rvar[i].setLB(0);
					i++;
					}
			}
		}
		IloConversion conv = solver.conversion(rvar, IloNumVarType.Bool);
		solver.add(conv);
		solver.setParam(IloCplex.DoubleParam.TimeLimit,10*60);
	}
	
	public void add(LinkedList<Transaction> l) throws IloException{
		previousTrans.addAll(l);
		IloColumnArray g=null;
		double[] d =new double[l.size()];
		double[] d1 =new double[l.size()];
		for(int i=0;i<d.length;i++){
			d[i]=1;
			d1[i]=-1;
		}
		g=solver.columnArray(sizemin,d1).and(solver.columnArray(sizemax,d));
		d =new double[l.size()];
		for(int i=0;i<d.length;i++){
			d[i]=-datasets.size();
		}
		d1 =new double[l.size()];
		g=g.and(solver.columnArray(maxfun,d));
		for(Itemset is: list){
			d =new double[l.size()];
			int i=0;
			for(Transaction t:l){
				if(t.getS().containsAll(is.getS())){
					d[i]=1;
					d1[i]=-1;
				}else{
					d[i]=0;
					d1[i]=0;
				}
				i++;
			}
			g=g.and(solver.columnArray(is.getMinc(),d1).and(solver.columnArray(is.getMaxc(),d)));
		}
		IloNumVar[] var=solver.numVarArray(g,0, Double.MAX_VALUE);
		int i=0;
		for(Transaction t:l){
		    t.setX(var[i]);
			i++;
		}
		allTransactions.addAll(l);
		//we have to addd the change in the optimization
	}

	public DataSet getDataset() throws UnknownObjectException, IloException {
		// TODO Auto-generated method stub
		DataSet d=new DataSet();
		//System.out.println("genero dddddddddddddddddddddddddddddddddddddddddddd");
		for(Transaction t:allTransactions){
			double c=solver.getValue(t.getX());
			if(c>0){
				//System.out.println(t);
				TransDupl td=new TransDupl();
				int yy=(int) c;
				if(c-((double)yy)>=0.5){
					yy=yy+1;
				}
				td.setV(yy);
				d.getDataset().put(t, td);
			}
			
		}
		return d;
	}
	
	
	
	

}
