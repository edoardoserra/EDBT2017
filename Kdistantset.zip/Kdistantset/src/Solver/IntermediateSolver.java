package Solver;

import java.util.HashSet;
import java.util.LinkedList;

import ColumnGeneration.ExactSolver;
import ColumnGeneration.ExactSolver1;
import ColumnGeneration.ExactSolver2;
import Itemset.DataSet;
import Itemset.Itemset;
import Itemset.Transaction;
import ilog.concert.IloException;
import ilog.concert.IloObjective;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

public class IntermediateSolver {
	LinkedList<DataSet> datasets= new LinkedList<>();
	LinkedList<Itemset> list=new LinkedList<>();
	int sl;
	int su;
	SolverCplex sc;
	ExactSolver es;

	
	public IntermediateSolver(LinkedList<DataSet> datasets,LinkedList<Itemset> list,int sl,int su,int editdistance) throws IloException{
		this.datasets=datasets;
		this.list=list;
		this.sl=sl;
		this.su=su;
		sc=new SolverCplex(datasets, list, sl, su);
		if(editdistance>0)
			es=new ExactSolver1(list, datasets,editdistance);
		else
			es=new ExactSolver2(list, datasets);
	}

	public DataSet solve(int k){
		try {
			sc.Initialization();
			int ii=0;
			//sc.getSolver().exportModel("m"+ii+".lp");
			ii++;
			sc.getSolver().solve();
			//System.out.println("master          ffffffffffffffffffffffffffffffffffffff"+sc.solver.getObjValue());
			LinkedList<Transaction> lt=es.generate(sc, k);
			//System.out.println("cg        ffffffffffffffffffffffffffffffffffffff"+lt.size());
			while(lt.size()>0){
				sc.add(lt);
				//sc.getSolver().exportModel("m"+ii+".lp");
				ii++;
				sc.getSolver().solve();
				//System.out.println("master          ffffffffffffffffffffffffffffffffffffff"+sc.solver.getObjValue());
				lt=es.generate(sc, k);
				//System.out.println("cg         ffffffffffffffffffffffffffffffffffffff"+lt.size());
				
			}
			sc.setBinary();
			//System.out.println("generaBinary          ffffffffffffffffffffffffffffffffffffff");
			
			sc.getSolver().solve();
			return sc.getDataset();
			
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public DataSet solve2(int k){
		try {
			sc.Initializationsec();
			//sc.setBinary();
			//sc.solver.exportModel("cciall.lp");
			sc.getSolver().solve();
			//System.out.println("master          ffffffffffffffffffffffffffffffffffffff"+sc.solver.getObjValue());
			LinkedList<Transaction> lt=es.generate(sc, k);
			while(lt.size()>0){
				sc.add(lt);
				sc.getSolver().solve();
				sc.check();
				//System.out.println("master          ffffffffffffffffffffffffffffffffffffff"+sc.solver.getObjValue());
				lt=es.generate(sc, k);
			}
			sc.setBinary();
			sc.solver.exportModel("cciall.lp");
			//System.out.println("dddeddd");	
			sc.getSolver().solve();
			return sc.getDataset();
			
		} catch (IloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	

}
