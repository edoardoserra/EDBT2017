package Itemset;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class DataReader {
	static HashMap<String,Integer> trans = new HashMap<>();
	public  static LinkedList<DataSet> read(String h){
		LinkedList<DataSet> list=new LinkedList<>();
		//LinkedList<Transaction> trans = new LinkedList<>();
		try {
			HashMap<String, Integer> map=new HashMap<>(); 
			Scanner sc=new Scanner(new File(h));
			int v=0;
			while(sc.hasNext()){
				String g= sc.nextLine();
				//System.out.println(g);
				if(g.startsWith("item{")){
					StringTokenizer st=new StringTokenizer(g,"{,}");
					st.nextToken();
					while(st.hasMoreTokens()){
						String val=st.nextToken();
						//System.out.println("val:"+val);
						Integer id=map.get(val);
						if(id==null){
							id=v;
							v++;
							map.put(val,id);
						}
					}
				}else{
					HashMap<Integer,String> set=new HashMap<>();
					StringTokenizer st=new StringTokenizer(g, "[]");
					StringTokenizer st1=new StringTokenizer(st.nextToken().trim(), "{,}");
					while(st1.hasMoreTokens()){
						String val=st1.nextToken();
						Integer id = map.get(val);
						if(id==null){
							id=v;
							v++;
							map.put(val,id);
						}
						set.put(id,val);
					}
					//st1=new StringTokenizer(st.nextToken(), ":");
					//list.add(new DataSet(set));
				}
			}
			String[] id =new String[map.keySet().size()];
			for(String h1:map.keySet()){
				id[map.get(h1)]=h1;
				
			}
			//DataSet.setD(id);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		String a = null;
		Integer x=0;
		for(DataSet d:list){
			a=d.toString();
			for(DataSet t:list){
				if(a.equals(t.toString())){
					x++;
				}
			}
			trans.put(a,x );
			//System.out.println(a);
			x=0;
		}
		System.out.println(trans);
		return list;
	}

		public static void main(String[] args) {
		for(DataSet h:read("data")){
			System.out.println(h);
			
			}
		}
		
	
		
}
