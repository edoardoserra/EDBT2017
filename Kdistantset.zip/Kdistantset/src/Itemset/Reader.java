package Itemset;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Reader {
	
	HashMap<String, Integer> map=new HashMap<>();
	
	public   LinkedList<Itemset> readItemset(String h){
		LinkedList<Itemset> list=new LinkedList<>();
		try { 
			Scanner sc=new Scanner(new File(h));
			int v=0;
			boolean b=false;
			while(sc.hasNext()){
				String g= sc.nextLine();
				//System.out.println(g);
				if(b==false&&g.startsWith("items{")){
					b=true;
					StringTokenizer st=new StringTokenizer(g,"{,}");
					st.nextToken();
					while(st.hasMoreTokens()){
						String val=st.nextToken();
						Integer id=map.get(val);
						if(id==null){
							id=v;
							v++;
							map.put(val,id);
						}
					}
					String hh=g.trim();
					if(hh.charAt(hh.length()-1)=='}')
						b=false;
				}else if(b){
					StringTokenizer st=new StringTokenizer(g,"{,}");
					while(st.hasMoreTokens()){
						String val=st.nextToken();
						Integer id=map.get(val);
						if(id==null){
							id=v;
							v++;
							map.put(val,id);
						}
					}
					String hh=g.trim();
					if(hh.charAt(hh.length()-1)=='}')
						b=false;
				}else
				{
					HashSet<Integer> set=new HashSet<>();
					StringTokenizer st=new StringTokenizer(g, "[]");
					StringTokenizer st1=new StringTokenizer(st.nextToken().trim(), "{,} ");
					while(st1.hasMoreTokens()){
						String val=st1.nextToken();
						Integer id=map.get(val);
						if(id==null){
							id=v;
							v++;
							map.put(val,id);
						}
						set.add(id);
					}
					st1=new StringTokenizer(st.nextToken(), ":,");
					list.add(new Itemset(set,Double.parseDouble(st1.nextToken()) ,Double.parseDouble(st1.nextToken())));
				}
			}
			String[] id =new String[map.keySet().size()];
			for(String h1:map.keySet()){
				id[map.get(h1)]=h1;
			}
			Itemset.setD(id);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	
	
	public  DataSet read(String h){
		try { 
			HashMap<String,Transaction> m=new HashMap<>();
			HashMap<Transaction,TransDupl> db=new HashMap<>();
			Scanner sc=new Scanner(new File(h));
			int v=0;
			while(sc.hasNext()){
				String g= sc.nextLine();
				//System.out.println(g);
					HashSet<Integer> set=new HashSet<>();
					StringTokenizer st1=new StringTokenizer(g, ", ");
					while(st1.hasMoreTokens()){
						String val=st1.nextToken();
						Integer id=map.get(val);
						if(id==null){
							id=v;
							v++;
							map.put(val,id);
						}
						set.add(id);
					}
					TreeSet<Integer> treeSet=new TreeSet<>(set);
					String key=treeSet.toString();
					Transaction t=m.get(key);
					if(t!=null){
						TransDupl td=db.get(t);
						td.setV(td.getV()+1);
					}else{
						t=new Transaction(set);
						TransDupl td=new TransDupl();
						td.setV(1);
						m.put(key, t);
						db.put(t, td);
					}
					
			}
			DataSet dd=new DataSet();
			dd.setDataset(db);
			return dd;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
