package Itemset;

import ilog.concert.IloRange;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;



public class DataSet {


	HashMap<Transaction,TransDupl> dataset=new HashMap<>();

	public HashMap<Transaction,TransDupl> getDataset() {
		return dataset;
	}

	public void setDataset(HashMap<Transaction,TransDupl> dataset) {
		this.dataset = dataset;
	}
	

}


