package Itemset;

import java.util.HashSet;

import ilog.concert.IloNumVar;
import ilog.cplex.NumVarAlreadyInLPMatrixException;

public class Transaction {
	
	
	HashSet<Integer> s=new HashSet<>();
	IloNumVar x;
	
	public Transaction(HashSet<Integer> s) {
		super();
		this.s = s;
	}

	public HashSet<Integer> getS() {
		return s;
	}

	public void setS(HashSet<Integer> s) {
		this.s = s;
	}

	public IloNumVar getX() {
		return x;
	}

	public void setX(IloNumVar var) {
		this.x= var;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String gg="{";
		for(Integer i:s){
			gg+=Itemset.getD()[i]+",";
		}
		gg=gg.substring(0, gg.length()-1)+"} ";		
		return gg;
	}

	public boolean equawwlds(Object obj) {
		if (obj instanceof Transaction) {
			Transaction t = (Transaction) obj;
			return s.contains(t.s) && t.s.contains(s);
			
		}
		return false;
	}
	

	public int hashCwwodde() {
		// TODO Auto-generated method stub
		int r=0;
		for(Integer i :s){
			r+=i.hashCode();
		}
		return r;
	}
	
	
}
