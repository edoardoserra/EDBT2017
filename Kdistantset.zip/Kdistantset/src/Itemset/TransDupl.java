package Itemset;

import ilog.concert.IloNumVar;

public class TransDupl{
	
		
		int v;
		IloNumVar y;
		IloNumVar z;
		IloNumVar ymin;
		IloNumVar ymax;
		public int getV() {
			return v;
		}
		public void setV(int v) {
			this.v = v;
		}
		public IloNumVar getY() {
			return y;
		}
		public void setz(IloNumVar z) {
			this.z = z;
		}
		
		public IloNumVar getz() {
			return z;
		}
		public void setY(IloNumVar y) {
			this.y = y;
		}
		public IloNumVar getYmin() {
			return ymin;
		}
		public void setYmin(IloNumVar ymin) {
			this.ymin = ymin;
		}
		public IloNumVar getYmax() {
			return ymax;
		}
		public void setYmax(IloNumVar ymax) {
			this.ymax = ymax;
		}
	}

