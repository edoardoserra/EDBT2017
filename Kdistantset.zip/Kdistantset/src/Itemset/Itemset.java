package Itemset;

import java.util.HashSet;


import ilog.concert.IloRange;

public class Itemset {

	static String[] d;
	HashSet<Integer> s=new HashSet<>();
	double smin=0;
	double smax=0;
	IloRange minc;
	IloRange maxc;
	
	public Itemset(HashSet<Integer> s, double smin, double smax) {
		super();
		this.s = s;
		this.smin = smin;
		this.smax = smax;
	}
	
	public static String[] getD() {
		return d;
	}
	public static void setD(String[] d) {
		Itemset.d = d;
	}
	public HashSet<Integer> getS() {
		return s;
	}
	public void setS(HashSet<Integer> s) {
		this.s = s;
	}
	public double getSmin() {
		return smin;
	}
	public void setSmin(double smin) {
		this.smin = smin;
	}
	public double getSmax() {
		return smax;
	}
	public void setSmax(double smax) {
		this.smax = smax;
	}
	public IloRange getMinc() {
		return minc;
	}
	public void setMinc(IloRange minc) {
		this.minc = minc;
	}
	public IloRange getMaxc() {
		return maxc;
	}
	public void setMaxc(IloRange maxc) {
		this.maxc = maxc;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String gg="{";
		for(Integer i:s){
			gg+=d[i]+",";
		}
		gg=gg.substring(0, gg.length()-1)+"} "+ "["+smin+","+smax+"]";		
		return gg;
	}
	

}
