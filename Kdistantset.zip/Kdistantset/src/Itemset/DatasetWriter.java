package Itemset;


import java.awt.event.ItemEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.TreeSet;

public class DatasetWriter {
	private PrintStream output = null;
	private FileOutputStream file = null;


	public DatasetWriter(String percorso) {
		try {
			File fil=new File(percorso);
			if(fil.exists())
				fil.delete();
			file = new FileOutputStream(percorso);
			output = new PrintStream(file);}catch(Exception e){}
			
	}
	
	@SuppressWarnings("unchecked")
	public void writeDataset(DataSet ds){
		for(Transaction t:ds.getDataset().keySet()){
			TransDupl td=ds.dataset.get(t);
			for(int i=0; i<td.getV();i++){
				for(Integer o:t.getS()){
					output.print(Itemset.getD()[o]+" ");
				}
				output.println("");
			}
		}
		output.close();
	}
	
	
	
}

