package PreSolver;

import java.util.LinkedList;

import Itemset.DataSet;
import Itemset.Itemset;
import Itemset.Transaction;
import ilog.concert.IloException;

public class PreSolver {
	
	public static DataSet solver(LinkedList<Itemset> list,int sl,int su, int k) throws IloException{
		
		PreSolverCplex psc=new PreSolverCplex(list, sl, su);
		psc.Initialization();
		psc.solver.solve();
		//psc.solver.exportModel("jj.lp");
		ExactSolver es=new ExactSolver(list);
		LinkedList<Transaction> l=es.generate(psc, k);
		//System.out.println(l.size());
		while(l.size()>0 && psc.solver.getObjValue()>0){
			psc.add(l);
			psc.solver.solve();
			//psc.solver.exportModel("jj1.lp");
			//es=new ExactSolver(list);
			l=es.generate(psc, k);
			//System.out.println(psc.solver.getObjValue()+" "+l.size());
			//break;
		}
		DataSet d=psc.getDataset();
		System.out.println("Error="+psc.error);
		return d;
	}

}
