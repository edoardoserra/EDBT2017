package PreSolver;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

import Itemset.DataSet;
import Itemset.Itemset;
import Itemset.Transaction;
import Solver.SolverCplex;
import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloNumVarType;
import ilog.concert.IloObjective;
import ilog.cplex.IloCplex;
import ilog.cplex.IloCplex.UnknownObjectException;

public class ExactSolver {
	IloCplex solver;
	LinkedList<IloNumVar> lista=new LinkedList<>();
	LinkedList<Itemset> list;
	HashMap<Integer, IloNumVar> val=new HashMap<>();
	int n;
	IloObjective objective;
	double treshold;
	
	

	
	public ExactSolver(LinkedList<Itemset> list) throws IloException {
		solver=new IloCplex();
		solver.setOut(new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
		});
		solver.setWarning(new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
		});
		//solver.setParam(IloCplex.DoubleParam.SolnPoolGap, 0.1);
		/* Solution Pool Intensity
		0	Automatic: let CPLEX choose; default
		1	Mild: generate few solutions quickly
		2	Moderate: generate a larger number of solutions
		3	Aggressive: generate many solutions and expect performance penalty
		4	Very aggressive: enumerate all practical solutions*/
		solver.setParam(IloCplex.IntParam.SolnPoolIntensity,1 );
		// time limit 10*60s
		solver.setParam(IloCplex.DoubleParam.TimeLimit,10*60);
		this.list=list;
		HashSet<Integer> a=new HashSet<>();
		IloNumExpr ex=null;
		for(int i=0;i<Itemset.getD().length;i++){
			IloNumVar var1=solver.numVar(0, 1,IloNumVarType.Bool);
			val.put(i,var1 );
			if(ex==null){
				ex=var1;
			}else{
				ex=solver.sum(ex, var1);
			}
		}
		solver.addGe(ex, 1);
		for(Itemset it:list){
			a.addAll(it.getS());
			IloNumVar h1=solver.numVar(0, 1,IloNumVarType.Bool);
			lista.add(h1);
			IloNumExpr expr=solver.prod(-1, h1);
			for(Integer h:it.getS()){
				IloNumVar h2=val.get(h);
				solver.addLe(solver.sum(h1,solver.prod(-1, h2)), 0);
				expr=solver.sum(expr,h2);
			}
			solver.addLe(expr,it.getS().size()-1);
		}
	}
	
	
	public LinkedList<Transaction> generate(PreSolverCplex sc, int k) throws UnknownObjectException, IloException{
		solver.setParam(IloCplex.IntParam.PopulateLim,k );
		LinkedList<Transaction> ris=new LinkedList<>();
		treshold=+sc.getSolver().getDual(sc.getSizemin())-sc.getSolver().getDual(sc.getSizemax());
		// remove solution wit value greater than CutUP
		solver.setParam(IloCplex.DoubleParam.CutUp,-treshold-0.01 );
		if(objective==null){
			IloNumExpr ex=null;
			Iterator<IloNumVar> c=lista.iterator();
			for(Itemset it: list){
				IloNumVar va=c.next();
				//System.out.println(sc.getSolver().getDual(it.getMinc())-sc.getSolver().getDual(it.getMaxc()));
				if(ex==null){
					ex=solver.prod(sc.getSolver().getDual(it.getMinc())-sc.getSolver().getDual(it.getMaxc()), va);
				}else{
					ex=solver.sum(ex,solver.prod(sc.getSolver().getDual(it.getMinc())-sc.getSolver().getDual(it.getMaxc()), va));
				}
			}
			objective=solver.addMinimize(ex);
		}else{
			Iterator<IloNumVar> c=lista.iterator();
			double[] arg1=new double[list.size()];
			IloNumVar[] arg2=new IloNumVar[list.size()];
			int i=0;
			for(Itemset it: list){
				arg2[i]=c.next();
				arg1[i]=sc.getSolver().getDual(it.getMinc())-sc.getSolver().getDual(it.getMaxc());
				i++;
			}
			solver.setLinearCoefs(objective, arg1, arg2);
		}
		solver.populate();
		solver.exportModel("ciao.lp");
		int numsol = solver.getSolnPoolNsolns();
		HashSet<String> b=new HashSet<String>();
		for (int i = 0; i < numsol; i++) {
			if(solver.getObjValue()+treshold<0.01){
				HashSet<Integer> v=new HashSet<>();
				String gg="";
				for(int j=0;j<Itemset.getD().length;j++){
					IloNumVar oo=val.get(j);
					//System.out.println(oo);
					double g=solver.getValue(oo,i);
					if(g>0.5){
						v.add(j);
						gg+=j;
					}
			}
			if(!b.contains(gg)){
				b.add(gg);
				ris.add(new Transaction(v));
			}
			
			}
			
	}
		solver.delSolnPoolSolns(0,numsol);
		//System.out.println(v);
		return ris;
	}

}
