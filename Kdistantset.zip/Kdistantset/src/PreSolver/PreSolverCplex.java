package PreSolver;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import Itemset.DataSet;
import Itemset.Itemset;
import Itemset.TransDupl;
import Itemset.Transaction;
import ilog.concert.IloColumnArray;
import ilog.concert.IloConversion;
import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloNumVarType;
import ilog.concert.IloObjective;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import ilog.cplex.IloCplex.UnknownObjectException;


public class PreSolverCplex {
	
	public LinkedList<Itemset> getList() {
		return list;
	}

	public void setList(LinkedList<Itemset> list) {
		this.list = list;
	}

	public HashSet<Transaction> getAllTransactions() {
		return allTransactions;
	}

	public void setAllTransactions(HashSet<Transaction> allTransactions) {
		this.allTransactions = allTransactions;
	}

	public IloCplex getSolver() {
		return solver;
	}

	public void setSolver(IloCplex solver) {
		this.solver = solver;
	}

	public IloRange getSizemin() {
		return sizemin;
	}

	public void setSizemin(IloRange sizemin) {
		this.sizemin = sizemin;
	}

	public IloRange getSizemax() {
		return sizemax;
	}

	public void setSizemax(IloRange sizemax) {
		this.sizemax = sizemax;
	}

	public int getSl() {
		return sl;
	}

	public void setSl(int sl) {
		this.sl = sl;
	}

	public int getSu() {
		return su;
	}

	public void setSu(int su) {
		this.su = su;
	}


	public IloObjective getMaxfun() {
		return maxfun;
	}

	public void setMaxfun(IloObjective maxfun) {
		this.maxfun = maxfun;
	}


	LinkedList<Itemset> list=new LinkedList<>();
	HashSet<Transaction> allTransactions;
	IloCplex solver;
	IloRange sizemin;
	IloRange sizemax;
	int sl;
	int su;
	IloObjective maxfun;
	HashMap<Transaction,Double> kt=new HashMap<>();
	
	public PreSolverCplex(LinkedList<Itemset> list,int sl,int su) throws IloException{
		solver=new IloCplex();
		solver.setOut(new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
		});
		solver.setWarning(new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
		});
		//solver.setOut(null);
		
		this.list=list;
		this.sl=sl;
		this.su=su;
	}
	
	
	public void Initialization() throws IloException{
		allTransactions=new HashSet<>();
		for(Itemset it:list){
			allTransactions.add(new Transaction(it.getS()));
		}
		for(Transaction t:allTransactions){
			t.setX(solver.numVar(0, Double.MAX_VALUE));
		}
	    IloNumExpr sum=null;
		IloNumExpr sum1=null;
		IloNumExpr opt=null;
		for(Itemset is: list){
			IloNumVar iv1=solver.numVar(0, Double.MAX_VALUE);
			IloNumVar iv2=solver.numVar(0, Double.MAX_VALUE);
			if(opt==null){
				opt=solver.sum(iv1,iv2);
			}else{
				opt=solver.sum(opt,solver.sum(iv1,iv2));
			}
			sum=solver.prod(-1, iv1);
			sum1=solver.prod(-1, iv2);;
			for(Transaction t:allTransactions){
				if(t.getS().containsAll(is.getS())){
						sum=solver.sum(sum,t.getX());
						sum1=solver.sum(sum1,solver.prod(-1, t.getX()));
				}
			}
			is.setMinc(solver.addLe(sum1, -is.getSmin()));
			is.setMaxc(solver.addLe(sum, is.getSmax()));
		}
		solver.addMinimize(opt);
		sum=null;
		sum1=null;
		for(Transaction t:allTransactions){
			if(sum==null){
				sum=t.getX();
				sum1=solver.prod(-1, t.getX());
			}else{
				sum=solver.sum(sum,t.getX());
				sum1=solver.sum(sum1,solver.prod(-1, t.getX()));
			}
		}
		sizemin=solver.addLe(sum1,-sl);
		sizemax=solver.addLe(sum, su);
		//solver.exportModel("model.lp");
	}
	
	
	
	
	public void add(LinkedList<Transaction> l) throws IloException{
		IloColumnArray g=null;
		double[] d =new double[l.size()];
		double[] d1 =new double[l.size()];
		for(int i=0;i<d.length;i++){
			d[i]=1;
			d1[i]=-1;
		}
		g=solver.columnArray(sizemin,d1).and(solver.columnArray(sizemax,d));
		for(Itemset is: list){
			d =new double[l.size()];
			d1 =new double[l.size()];
			int i=0;
			for(Transaction t:l){
				if(t.getS().containsAll(is.getS())){
					d[i]=1;
					d1[i]=-1;
				}else{
					d[i]=0;
					d1[i]=0;
				}
				i++;
			}
			g=g.and(solver.columnArray(is.getMinc(),d1).and(solver.columnArray(is.getMaxc(),d)));
		}
		IloNumVar[] var=solver.numVarArray(g,0, Double.MAX_VALUE);
		int i=0;
		for(Transaction t:l){
			//System.out.println(t);
		    t.setX(var[i]);
			i++;
		}
		allTransactions.addAll(l);
		//we have to addd the change in the optimization
	}
	double error=0;
	public DataSet getDataset() throws UnknownObjectException, IloException {
		// TODO Auto-generated method stub
		DataSet d=new DataSet();
		System.out.println("errore="+solver.getObjValue());
		for(Transaction t:allTransactions){
			double c=solver.getValue(t.getX());
				//System.out.println(t);
				TransDupl td=new TransDupl();
				int yy=(int) c;
				error+=c-((double)yy);
				if(c-((double)yy)>=0.5)
					yy=yy+1;
				td.setV(yy);
				d.getDataset().put(t, td);
		}
		return d;
	}

	public double getError() {
		return error;
	}

	public void setError(double error) {
		this.error = error;
	}
	
	
	
	

}
