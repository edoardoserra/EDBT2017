package ColumnGeneration;

import java.util.LinkedList;

import Itemset.Transaction;
import Solver.SolverCplex;
import ilog.concert.IloException;
import ilog.cplex.IloCplex.UnknownObjectException;

public interface ExactSolver {
	public LinkedList<Transaction> generate(SolverCplex sc, int k) throws UnknownObjectException, IloException;
}
