package ColumnGeneration;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

import Itemset.DataSet;
import Itemset.Itemset;
import Itemset.Transaction;
import Solver.SolverCplex;
import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloNumVarType;
import ilog.concert.IloObjective;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import ilog.cplex.IloCplex.UnknownObjectException;

public class ExactSolver2 implements ExactSolver{
	IloCplex solver;
	LinkedList<IloNumVar> lista=new LinkedList<>();
	LinkedList<Itemset> list;
	HashMap<Integer, IloNumVar> val=new HashMap<>();
	int n;
	IloRange objective;
	double treshold;

	

	
	public ExactSolver2(LinkedList<Itemset> list,LinkedList<DataSet> datasets) throws IloException {
		solver=new IloCplex();
		
		solver.setOut(new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
		});
		solver.setWarning(new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				// TODO Auto-generated method stub
				
			}
		});
		//solver.setParam(IloCplex.DoubleParam.SolnPoolGap, 0.1);
		/* Solution Pool Intensity
		0	Automatic: let CPLEX choose; default
		1	Mild: generate few solutions quickly
		2	Moderate: generate a larger number of solutions
		3	Aggressive: generate many solutions and expect performance penalty
		4	Very aggressive: enumerate all practical solutions*/
		solver.setParam(IloCplex.IntParam.SolnPoolIntensity,1 );
		// time limit 10*60s
		solver.setParam(IloCplex.DoubleParam.TimeLimit,10*60);
		n=datasets.size();
		this.list=list;
		HashSet<Transaction> allTransactions=new HashSet<>();
		//System.out.println(datasets.size());
		for(DataSet d:datasets){
			allTransactions.addAll(d.getDataset().keySet());
		}
		HashSet<Integer> a=new HashSet<>();
		for(int i=0;i<Itemset.getD().length;i++){
			val.put(i,solver.numVar(0, 1,IloNumVarType.Bool) );
		}
		for(Itemset it:list){
			a.addAll(it.getS());
			IloNumVar h1=solver.numVar(0, 1,IloNumVarType.Bool);
			lista.add(h1);
			IloNumExpr expr=solver.prod(-1, h1);
			for(Integer h:it.getS()){
				IloNumVar h2=val.get(h);
				solver.addLe(solver.sum(h1,solver.prod(-1, h2)), 0);
				expr=solver.sum(expr,h2);
			}
			solver.addLe(expr,it.getS().size()-1);
		}
		IloNumVar v=solver.numVar(1, Double.MAX_VALUE);
		IloNumVar sum=solver.numVar(1, Double.MAX_VALUE);
		IloNumExpr expr=solver.prod(-1, sum);
		for(int i=0;i<Itemset.getD().length;i++){
			expr=solver.sum(expr,val.get(i));
		}
		solver.addEq(expr, 0);
		//System.out.println(allTransactions);
		for(Transaction t: allTransactions){
			IloNumExpr ex=solver.sum(sum,solver.prod(-1,v));
			for(Integer i:t.getS()){
					ex=solver.sum(ex,solver.prod(-2,val.get(i)));
			}
			solver.addGe(ex,-t.getS().size());
		}
		solver.addMaximize(v);
		
	}
	
	static int count=0;
	public LinkedList<Transaction> generate(SolverCplex sc, int k) throws UnknownObjectException, IloException{
		solver.setParam(IloCplex.IntParam.PopulateLim,k);
		LinkedList<Transaction> ris=new LinkedList<>();
		treshold=-n+sc.getSolver().getDual(sc.getSizemin())-sc.getSolver().getDual(sc.getSizemax());
		//System.out.println(sc.getSolver().getDual(sc.getSizemin())+" "+sc.getSolver().getDual(sc.getSizemax()));
		// remove solution wit value greater than CutUP
		//solver.setParam(IloCplex.DoubleParam.CutUp,-treshold-0.0000001 );
		//System.out.println(treshold);
		if(objective==null){
			IloNumExpr ex=null;
			Iterator<IloNumVar> c=lista.iterator();
			for(Itemset it: list){
				IloNumVar va=c.next();
				//System.out.println(it+" "+(sc.getSolver().getDual(it.getMinc())+" "+sc.getSolver().getDual(it.getMaxc())));
				if(ex==null){
					ex=solver.prod(+sc.getSolver().getDual(it.getMinc())-sc.getSolver().getDual(it.getMaxc()), va);
				}else{
					ex=solver.sum(ex,solver.prod(+sc.getSolver().getDual(it.getMinc())-sc.getSolver().getDual(it.getMaxc()), va));
				}
			}
			objective=solver.addLe(ex,-treshold-0.1);
		}else{
			Iterator<IloNumVar> c=lista.iterator();
			double[] arg1=new double[list.size()];
			IloNumVar[] arg2=new IloNumVar[list.size()];
			int i=0;
			for(Itemset it: list){
				arg2[i]=c.next();
				arg1[i]=+sc.getSolver().getDual(it.getMinc())-sc.getSolver().getDual(it.getMaxc());
				i++;
			}
			solver.setLinearCoefs(objective, arg1, arg2);
			objective.setUB(-treshold-0.1);
		}
		//solver.exportModel("m"+count+".lp");
		count++;
		solver.populate();
		
		//solver.solve();
		int numsol = solver.getSolnPoolNsolns();
		//System.out.println(numsol);
		HashSet<String> b=new HashSet<String>();
		for (int i = 0; i < numsol; i++) {
				HashSet<Integer> v=new HashSet<>();
				String gg="";
				for(int j=0;j<Itemset.getD().length;j++){
					IloNumVar oo=val.get(j);
					//System.out.println(oo);
					double g=solver.getValue(oo,i);
					if(g>0.5){
						v.add(j);
						gg+=j;
					}
				
				}
				if(!b.contains(gg)){
					b.add(gg);
					ris.add(new Transaction(v));
				}
				
				//System.out.println(v);
		}
		solver.delSolnPoolSolns(0,numsol);
		//System.out.println(ris);
		return ris;
	}

}
